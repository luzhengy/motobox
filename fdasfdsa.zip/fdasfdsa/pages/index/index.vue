<template>
	<view class="my-riding">
		<view class="top-box">
				<!-- <map style="width: 100%; height: 100%;" :latitude="latitude" :longitude="longitude" :markers="covers"  show-compass="true" scale="18">
				</map> -->
		</view>
	    <view class="start-riding">
			   <button type="primary" @click="handleStartRiding">开始骑行</button>
		</view>
	 
	</view>
</template>
<script>
	export default {
		onLoad() {
			 // console.log("我竖起来了")
		  //  // 进入当前页面 自动切换成固定横屏
		  //  // #ifdef APP-PLUS
		  //  plus.screen.lockOrientation("landscape-primary");
		  //  // #endif
		 },
		 onUnload() {
		   // // 退出当前页面时 自动切换成竖屏
		   // // #ifdef APP-PLUS
		   // plus.screen.lockOrientation("portrait-primary");
		   // // #endif
		  
		 },
		data() {
			return {
				id:0, // 使用 marker点击事件 需要填写id
							title: 'map',
							latitude: 39.909,
							longitude: 116.39742,
							covers: [{
								latitude: 39.909,
								longitude: 116.39742,
								iconPath: '../../../static/location.png'
							}, {
								latitude: 39.90,
								longitude: 116.39,
								iconPath: '../../../static/location.png'
							}]
			}
		},
		methods: {
			handleStartRiding(){
				 this.$router.push("/pages/ride/ride")
			}
		},
	
	}
</script>
<style lang="scss">
	.my-riding {
		  position: relative;
		// width: 100vw;
		// height: 100vh;
         overflow: hidden;
		.top-box {
			width: 100%;
			height: 65%;
		}
		.start-riding{
			 position: fixed;
			 width: 100%;
			 bottom: 50px;
			 left: 0px;
			 
		}
	
	}
</style>
