<template>
	<view class="ridingBox">
		<!-- 骑行速度仪表盘 -->
		<view class="ride-speed-meter">
			<uni-chart :option="option"   ref='chart'  />
		</view>
		<!-- 骑行数据 -->
		 <uni-grid :column="2"  class='rideTable'>
		 	<uni-grid-item   v-for='item in rideTableData' :key='item.text'>
				<view class="text">
					<i class='iconfont' :class='item.iconName'></i>
				{{item.text}}
				</view>
				
		 		<view class="value">{{item.value}}</view>
		 	</uni-grid-item>
		 </uni-grid>
		 <!-- 指南罗盘 -->
		 <Heading class="indicator-bg" :size="compassSize" :heading="compassHeading"/>
	</view>

</template>

<script>
	import {  Heading} from  'vue-flight-indicators'
	export default {
		 components: {
		    Heading,
		  },
		data() {
			return {
				option: {
					series: [{
						type: 'gauge',
						min: 0,
						max: 180,
						splitNumber: 12,
						axisLine: {
							lineStyle: {
								width: 30,
								color: [
									[0.3, '#67e0e3'],
									[0.7, '#37a2da'],
									[1, '#fd666d']
								]
							}
						},
						pointer: {
							itemStyle: {
								color: 'inherit'
							}
						},
						axisTick: {
							distance: -30,
							length: 6,
							lineStyle: {
								color: '#fff',
								width: 2
							}
						},
						splitLine: {
							distance: -30,
							length: 30,
							lineStyle: {
								color: '#fff',
								width: 4
							}
						},
						axisLabel: {
							color: 'inherit',
							distance: 35,
							fontcompassSize: 10
						},
						detail: {
							valueAnimation: true,
							formatter: '{value} km/h',
							color: 'inherit',
							fontSize: 20
						},
						data: [{
							value: 20
						}]
					}]
				},
				// 速度仪表盘速度变化定时器
				rideSpeedChangeTimer: null,
				// 速度仪表盘
			    chart:null,
				// 骑行数据
				rideTableData:[
					 {
					   text:'距离(km)',
					   value:0.00,
					   iconName:"icon-zuoce-guidao"
					 },
					 {
					   text:'时间',
					   value:'00:00:15',
					   iconName:"icon-shijian"
					 },
					 {
					   text:'均速(km/h)',
					   value:'0.0',
					   iconName:"icon-suduspeed8"
					 },
					 {
					   text:'极速(km/h)',
					   value:'0.0',
					   iconName:"icon-suduspeed8"
					 },
					 {
					   text:'海拔(m)',
					   value:'0.0',
					   iconName:"icon-tiankuaihaiba"
					 },
					 {
					   text:'气温(°C)',
					   value:'0',
					   iconName:"icon-wendu1"
					 }
				],
				// 指南针配置
				   compassSize:100,
				    compassHeading:80, //航向
			}
		},
		methods: { 
		},
		mounted() {
			//随机改变速度仪表盘显示数字
			this.rideSpeedChangeTimer = setInterval(() => {
				this.option['series'][0]['data'][0]['value'] =  parseInt(Math.random() * 180)
				this.compassHeading=parseInt(Math.random() * 100)
				setTimeout( this.$refs.chart.setOption(this.option), 500);
			}, 2000)
			
		}
	}
</script>
<style lang='scss'>
	.ridingBox{
		 position: relative;
		 .ride-speed-meter {
		 	margin: 0 auto;
		 	width: 100%;
		 	height: 320px;
		 }
		 .indicator-bg{
			 position: absolute;
			 top: 0px;
			 left: 0px;
		 }
		 .rideTable{
		 	 .uni-grid-item{
		 		   height: 54px !important;
		 		   .text{
		 			    float: left;
		 				width: 100%;
		 				 height: 100%;
		 		   }
		 		   .value{
		 			    float: left;
		 				width: 50%;
		 				 height: 100%;
		 		   }
		 	 }
		 }
	}
	
</style>
