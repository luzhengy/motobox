<template>
	<view class="my-riding">
		<view class="top-box">
				<map style="width: 100%; height: 100%;" :latitude="latitude" :longitude="longitude" :markers="covers"  show-compass="true" scale="18">
				</map>
		</view>
		<view class="riding-status-box">
			<view class="riding-status">
				<view class="box">
					<view class="num">01:57:14</view>
					<view class="text">骑行时间</view >
				</view>
				<view class="box">
					<view class="num">100</view>
					<view  class="text">里程Km</view >
				</view class="box">
<!-- 					<view class="box">
						<view class="num">23</view>
						<view  class="text">温度&deg;C</view >
					</view>
					<view class="box">
						<view class="num">15</view>
						<view class="text">海拔m</view >
					</view>
 -->			</view>
			<view class="riding-incline">
				   <!-- <button type="primary">开始骑行</button> -->
				   <!-- 左倾角度 -->
				    <view class="incline-left">
						  0&deg;
					</view>
					<!-- 图标 -->
					<view class="icon-box">
						   
					</view>
					<!--右倾角度 -->
					<view class="incline-right">
						  15&deg;
					</view>
			</view>

		</view>
	</view>
</template>
<script>
	export default {
		onLoad() {
			 console.log("我竖起来了")
		   // 进入当前页面 自动切换成固定横屏
		   // #ifdef APP-PLUS
		   plus.screen.lockOrientation("landscape-primary");
		   // #endif
		 },
		 onUnload() {
		   // 退出当前页面时 自动切换成竖屏
		   // #ifdef APP-PLUS
		   plus.screen.lockOrientation("portrait-primary");
		   // #endif
		  
		 },
		data() {
			return {
				id:0, // 使用 marker点击事件 需要填写id
							title: 'map',
							latitude: 39.909,
							longitude: 116.39742,
							covers: [{
								latitude: 39.909,
								longitude: 116.39742,
								iconPath: '../../../static/location.png'
							}, {
								latitude: 39.90,
								longitude: 116.39,
								iconPath: '../../../static/location.png'
							}]
			}
		},
		methods: {
   
  
		},
	
	}
</script>
<style lang="scss">
	.my-riding {
		width: 100vw;
		height: 100vh;
         overflow: hidden;
		.top-box {
			width: 100%;
			height: 65%;

		}
		.riding-status-box {
			width: 100%;
			height: 35%;
			background: #F5F5F5;
			padding-top: 15px;
			.riding-status{
				display: flex;
				flex-wrap: wrap; 	
			    .box{
				   width: 50%;
				   text-align:center;
				   margin-bottom:10px;
				     .num{
						 font-size:27px;
						 white-space:nowrap;
						 color:$uni-text-color;
					 }
                     .text{
						  clor:rgba(36,43,33,1);
						  font-size: 16px;
					 }
				}
			}
			.riding-incline{
				display:flex;
				height: calc(100% - 160px);
				windth: calc(100% - 20px);
				margin: 0 10px;
				text-align:center;
				margin-top:10px;
				border-top: 1px solid #ccc;
				 .incline-left{
					  width: 30%;
					  display: flex;
					   justify-content: flex-end;
					   align-items: center;
					  font-size:36px;
				 }
			     .icon-box{
					 width:40%
				 }
				 .incline-right{
					 wdith:30%;
					display: flex;
					 justify-content: flex-start;
					 align-items: center;
					 font-size:36px;
				 }
			}
		}
	}
</style>
