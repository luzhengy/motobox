<template>
	<view class='my'>
		<view class="tab">
			<utemplate v-for="(item,index) in tabs" :key='item'>
				<view class="title" :class="item.checked?'checked-title':''" @click="handleSelectTab(index)">
					<text>{{item.text}}</text>
					<uni-icons :type="item.iconName" size="20" :color="item.iconColor"></uni-icons>
				</view>
			</utemplate>

		</view>
		<view class="content">
            <view class='content-item' v-for='(item,index) in content' :key='index'>
				    <text v-if='index==checkedTabIndex'>{{item.text}} </text>  
			</view> 
		</view>

	</view>
</template>
<script>
	export default {
		data() {
			return {
				tabs: [{
						text: '系统设置',
						iconName: 'right',
						iconColor: '#C20000',
						checked: true,
					},
					{
						text: '仪表设置',
						iconName: 'right',
						iconColor: '#000',
						checked: false,
					},
					{
						text: '骑行设置',
						iconName: 'right',
						iconColor: '#000',
						checked: false,
					}, {
						text: '关于我们',
						iconName: 'right',
						iconColor: '#000',
						checked: false,
					}
				],
				checkedTabIndex:0,
				content:[
					 {
                         text:"系统设置内容"
					 },
					 {
					     text:"仪表设置内容"
					 },
					 {
					     text:"骑行设置内容"
					 },
					 {
					     text:"关于我们内容"
					 }
				]

			}
		},

		methods: {
			handleSelectTab(checkedItemIndex) {
				this.checkedTabIndex=checkedItemIndex
				this.tabs = this.tabs.map((item, index) => {
					if (checkedItemIndex == index) {
						return {
							...item,
							iconColor: '#C20000',
							checked: true,
						}
					} else {
						return {
							...item,
							iconColor: '#000',
							checked: false,
						}
					}
				})
			}
		}
	}
</script>


<style lang="scss">
	.my {
		width: 100vh;
		height: 100vh;
		background-color: #F8F8F8;
		font-size: 16px;
		border-top: 1px solid #ccc;

		.tab {
			float: left;
			width: 130px;
			height: 100vh;
			border-right: 1px solid #ccc;

			.title {
				height: 40px;
				line-height: 40px;
				width: 100%;
				padding-left: 20px;
				box-sizing: border-box;
				background-color: #f8f8f8;
				border-bottom: 1px solid #ccc;

				uni-text {
					margin-right: 20px;
				}

				.uni-icons {
					margin-top: 2px;
				}
			}

			.checked-title {
				background-color: #fff;
			}
		}
         .content{
			   float: left;
			    
		 }
	}
</style>
